class MOES:
    def __init__(self) -> None:
        pass

    def update(self):
        pass
